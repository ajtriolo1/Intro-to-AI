from Test import test_agents, plot


if __name__ == '__main__':
    test_agents()
    plot()